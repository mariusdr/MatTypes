#include <inrop/libcumanip/libcumanip.h>

#include <inrop/planning/MotionTrajectory.h>
#include <inrop/environment/State.h>

#include <thrust/host_vector.h>

#include <inrop/libcumanip/math_types.hpp>
#include <inrop/libcumanip/manip_optimizer_op.h>

#include <vector>
#include <iostream>

namespace cumanip
{


class CudaManipulability::Impl
{
public:

    Impl(inrop::planning::MotionTrajectoryPtr motion, 
         float dw0, float dw1, float dw2, float dw3, float dw4, float dw5, float max_dist):
         input_motion(motion->clone()), dist_weights(mt::identity<6, 6>()), max_dist(max_dist),
         offset_transformation(mt::identity<4, 4>())
    {
        dist_weights.data[0 * 6 + 0] = dw0;
        dist_weights.data[1 * 6 + 1] = dw1;
        dist_weights.data[2 * 6 + 2] = dw2;
        dist_weights.data[3 * 6 + 3] = dw3;
        dist_weights.data[4 * 6 + 4] = dw4;
        dist_weights.data[5 * 6 + 5] = dw5;
    }

    void optimize();

    void compute_manipulability(float& tmanip, float& rmanip);

    size_t num_solutions() const;
    
    inrop::planning::MotionTrajectoryPtr get_solution(size_t i) const;    
    
    float get_manip(size_t i) const;

    void set_offset_transform(const std::vector<float>& vals);

private:

    inrop::planning::MotionTrajectoryPtr input_motion;
    std::vector<inrop::planning::MotionTrajectoryPtr> solutions; 
    std::vector<float> manip_values;

    mt::Matrix<6, 6> dist_weights;
    
    float max_dist;
    mt::Matrix4f offset_transformation;
};


void convert_to_statevec(const inrop::planning::MotionTrajectoryPtr motion, thrust::host_vector<mt::State>& states)
{
    std::vector<inrop::environment::StatePtr> inrop_states(motion->states());
    for (auto it = inrop_states.begin(); it != inrop_states.end(); ++it)
    {
        inrop::environment::StatePtr inrop_state = *it;
        std::vector<double> jvs;
        inrop_state->getValues(jvs);
        mt::State state = mt::state(jvs[0], jvs[1], jvs[2], jvs[3], jvs[4], jvs[5]);
        states.push_back(state);
    }
}

void convert_to_motiontraj(const thrust::host_vector<mt::State>& states, inrop::planning::MotionTrajectoryPtr motion, 
                           inrop::environment::StatePtr curr)
{
    size_t N = states.size();
    std::vector<inrop::planning::MotionTrajectory::TrajectoryPoint> trajectory(N);
    
    for (size_t i = 0; i < states.size(); ++i)
    {
        const mt::State jv = states[i];
        curr->setJointValue("shoulder_pan_joint", jv.data[0]);
        curr->setJointValue("shoulder_lift_joint", jv.data[1]);
        curr->setJointValue("elbow_joint", jv.data[2]);
        curr->setJointValue("wrist_1_joint", jv.data[3]);
        curr->setJointValue("wrist_2_joint", jv.data[4]);
        curr->setJointValue("wrist_3_joint", jv.data[5]);
        trajectory[i].state = curr->clone();
        trajectory[i].state->setTime((double)(i + 1) / (double)(1 + N));
    }
    motion->setTrajectory(trajectory);
}


void CudaManipulability::Impl::optimize() 
{
    std::cout << "Libcumanip::run\n";
    thrust::host_vector<mt::State> states;
    convert_to_statevec(input_motion, states);
    std::cout << states.size() << " input states \n";
    std::cout << states[0] << "\n";
    std::cout << states[1] << "\n";
    std::cout << states[2] << "\n";
    std::cout << states[3] << "\n";
    std::cout << states[4] << "\n";

    cumanip::OptimizerResult opt_result = cumanip::run_optimizer(states, dist_weights, max_dist, offset_transformation);
    size_t n = opt_result.trajectories.size();
    
    std::cout << n << " optimizer results collected\n";

    for (size_t i = 0; i < n; ++i)
    {
        thrust::host_vector<mt::State> solution = opt_result.trajectories[i];
        float mv = opt_result.manip_values[i];

        inrop::planning::MotionTrajectoryPtr sol_motion(new inrop::planning::MotionTrajectory("manipulator"));
        if (solution.size() > 0)
        {
            convert_to_motiontraj(solution, sol_motion, input_motion->get(0));
        }

        solutions.push_back(sol_motion);
        manip_values.push_back(mv);
    }
}

void CudaManipulability::Impl::set_offset_transform(const std::vector<float>& vals)
{
    if (vals.size() != 16)
    {
        return;
    }

    mt::Matrix4f transform;
    for (int i = 0; i < 4; ++i)
    {
        for (int j = 0; j < 4; ++j)
        {
            transform.data[i * 4 + j] = vals[i * 4 + j];
        }
    }
    offset_transformation = transform;
}

void CudaManipulability::Impl::compute_manipulability(float& tmanip, float& rmanip) 
{
    thrust::host_vector<mt::State> states;
    convert_to_statevec(input_motion, states);
    cumanip::compute_manip_single_traj(states, tmanip, rmanip);
}

size_t CudaManipulability::Impl::num_solutions() const 
{
    return solutions.size();
}

inrop::planning::MotionTrajectoryPtr CudaManipulability::Impl::get_solution(size_t i) const
{
    return solutions[i];
}

float CudaManipulability::Impl::get_manip(size_t i) const 
{
    return manip_values[i];
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////

CudaManipulability::CudaManipulability(inrop::planning::MotionTrajectoryPtr motion,
                                       float dw0, float dw1, float dw2, float dw3, float dw4, float dw5,
                                       float max_dist) : 
    impl(new CudaManipulability::Impl(motion, dw0, dw1, dw2, dw3, dw4, dw5, max_dist))
{
}

CudaManipulability::~CudaManipulability()
{
    delete impl;
}

void CudaManipulability::optimize()
{
    impl->optimize();
}

void CudaManipulability::compute_manipulability(float &tmanip, float &rmanip)
{
    impl->compute_manipulability(tmanip, rmanip);
}

size_t CudaManipulability::num_solutions() const
{
    return impl->num_solutions();
}

inrop::planning::MotionTrajectoryPtr CudaManipulability::get_solution(size_t i) const
{
    return impl->get_solution(i);
}

float CudaManipulability::get_manip(size_t i) const
{
    return impl->get_manip(i);
}

void CudaManipulability::set_offset_transform(const std::vector<float>& vals)
{
    impl->set_offset_transform(vals);
}


} // namespace cumanip