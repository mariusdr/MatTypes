#ifndef LIBCUMANIP_TRAJECTORIES_INVERSE_KINEMATICS_H
#define LIBCUMANIP_TRAJECTORIES_INVERSE_KINEMATICS_H

#include <inrop/libcumanip/kinematics.hpp>
#include <inrop/libcumanip/typedefs.h>
#include <inrop/libcumanip/cuda_utils.h>

#include <cstring>
#include <iostream>

#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/execution_policy.h>
#include <thrust/tuple.h>

#include <curand_kernel.h>

namespace cumanip
{

struct IKSolution 
{
    int num_solutions;
    mt::Matrix<8, 6> states;
    unsigned char status[8];
};

__host__ inline
std::ostream& operator<<(std::ostream& os, const IKSolution& sol);

__host__ inline 
void run_inverse_kin(Mat4_DevIter in_first, Mat4_DevIter in_last, IKSolution_DevIter out_first);

__host__ inline 
void run_inverse_kin(Mat4_HostIter in_first, Mat4_HostIter in_last, IKSolution_HostIter out_first);


/////////////////////////////////////////////////////////////////////////////////////////////////

struct RunIKOp
{
    __host__ __device__
    IKSolution operator()(const mt::Matrix4f& transform)
    {
        URKInverseKinematics ik;
        int n = ik.solve(transform);

        IKSolution sol;
        sol.num_solutions = n;
        sol.states = ik.get_solutions();
        memcpy(sol.status, ik.get_status(), 8 * sizeof(unsigned char));
        
        return sol;
    }
};


__host__ inline 
void run_inverse_kin(Mat4_DevIter in_first, Mat4_DevIter in_last, IKSolution_DevIter out_first)
{
    RunIKOp ikOp;
    thrust::transform(in_first, in_last, out_first, ikOp);
    CUDA_ASSERT(cudaGetLastError());
}

__host__ inline 
void run_inverse_kin(Mat4_HostIter in_first, Mat4_HostIter in_last, IKSolution_HostIter out_first)
{
    RunIKOp ikOp;
    thrust::transform(in_first, in_last, out_first, ikOp);
}

__host__ inline
std::ostream& operator<<(std::ostream& os, const IKSolution& sol)
{
    os << sol.states;
    return os;
}


/////////////////////////////////////////////////////////////////////////////////////////////////

template <size_t NumSamples>
struct RunTranslation3DIkOp
{
    static const size_t NumRows = NumSamples * 8;

    using OutMatrix = mt::Matrix<NumRows, 6>;
    using InMatrix = mt::Matrix<NumSamples, 3>;

    __device__ __host__
    OutMatrix operator()(const mt::Vector3f& xyz, const InMatrix& rpy_vals)
    {
        OutMatrix states(0.f);

        for (size_t i = 0; i < NumSamples; ++i)
        {
            mt::Vector3f rpy = rpy_vals.get_row(i);
            mt::Matrix4f pose = mt::affine(mt::fromRPY(rpy), xyz);

            URKInverseKinematics ik;
            size_t n = ik.solve(pose);
            const mt::Matrix<8, 6>& sol = ik.get_solutions();

            states.set_row(8 * i + 0, sol.get_row(0));
            states.set_row(8 * i + 1, sol.get_row(1));
            states.set_row(8 * i + 2, sol.get_row(2));
            states.set_row(8 * i + 3, sol.get_row(3));
            states.set_row(8 * i + 4, sol.get_row(4));
            states.set_row(8 * i + 5, sol.get_row(5));
            states.set_row(8 * i + 6, sol.get_row(6));
            states.set_row(8 * i + 7, sol.get_row(7));
        }

        return states;
    }

    __device__ __host__
    OutMatrix operator()(const thrust::tuple<mt::Vector3f, InMatrix>& p)
    {
        return (*this)(thrust::get<0>(p), thrust::get<1>(p));
    }

};



} // namespace cumanip
#endif