#ifndef LIBCUMANIP_KERNELS_H
#define LIBCUMANIP_KERNELS_H

#include <thrust/device_vector.h>
#include <thrust/host_vector.h>

#include <inrop/libcumanip/typedefs.h>
#include <inrop/libcumanip/math_types.hpp>
#include <inrop/libcumanip/extract_traj_by_status.h>

namespace cumanip
{
namespace kernels
{


void extract_by_status(State_HostIter in_begin, State_HostIter in_end, State_HostIter out_begin, 
                       unsigned char target_status);










} // namespace kernels
} // namespace cumanip
#endif