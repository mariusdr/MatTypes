#ifndef LIBCUMANIP_MANIPULABILITY_OP_H
#define LIBCUMANIP_MANIPULABILITY_OP_H

#include <inrop/libcumanip/kinematics.hpp>
#include <inrop/libcumanip/typedefs.h>
#include <inrop/libcumanip/cuda_utils.h>
#include <inrop/libcumanip/inverse_kinematics_op.h>

#include <cstring>
#include <iostream>

#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/execution_policy.h>
#include <thrust/tuple.h>
#include <thrust/functional.h>
#include <thrust/reduce.h>



namespace cumanip
{

__host__ inline void compute_translational_manipulability(State_DevIter in_first, State_DevIter in_last, Float_DevIter out_first);
__host__ inline void compute_translational_manipulability(IKSolution_DevIter in_first, IKSolution_DevIter in_last, Vec8_DevIter out_first);
__host__ inline void compute_translational_manipulability(State_HostIter in_first, State_HostIter in_last, Float_HostIter out_first);
__host__ inline void compute_translational_manipulability(IKSolution_HostIter in_first, IKSolution_HostIter in_last, Vec8_HostIter out_first);

__host__ inline float min_translational_manipulability(State_DevIter in_begin, State_DevIter in_end);

__host__ inline void compute_rotational_manipulability(State_DevIter in_first, State_DevIter in_last, Float_DevIter out_first);
__host__ inline void compute_rotational_manipulability(IKSolution_DevIter in_first, IKSolution_DevIter in_last, Vec8_DevIter out_first);
__host__ inline void compute_rotational_manipulability(State_HostIter in_first, State_HostIter in_last, Float_HostIter out_first);
__host__ inline void compute_rotational_manipulability(IKSolution_HostIter in_first, IKSolution_HostIter in_last, Vec8_HostIter out_first);

__host__ inline float min_rotational_manipulability(State_DevIter in_begin, State_DevIter in_end);

__host__ inline void compute_combine_manipulability(State_DevIter in_first, State_DevIter in_last, Float_DevIter out_first);
__host__ inline void compute_combined_manipulability(IKSolution_DevIter in_first, IKSolution_DevIter in_last, Vec8_DevIter out_first);
__host__ inline void compute_combined_manipulability(State_HostIter in_first, State_HostIter in_last, Float_HostIter out_first);
__host__ inline void compute_combined_manipulability(IKSolution_HostIter in_first, IKSolution_HostIter in_last, Vec8_HostIter out_first);


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

struct TManipOpState
{
    __host__ __device__ 
    float operator()(const mt::State& state)
    {
        cumanip::Manipulability algo;
        algo.solve(state);
        return algo.trans_manip();
    }

    __host__ __device__
    mt::Vector<8> operator()(const IKSolution& sol)
    {
        mt::Vector<8> v(-1.f);
        int n = sol.num_solutions;
        for (int i = 0; i < n; ++i)
        {
            cumanip::Manipulability algo;
            algo.solve(sol.states.get_row(i));
            v.data[i] = algo.trans_manip();
        }
        return v;
    }
};

__host__ inline
void compute_translational_manipulability(State_DevIter in_first, State_DevIter in_last, Float_DevIter out_first)
{
    TManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
    CUDA_ASSERT(cudaGetLastError());
}

__host__ inline
void compute_translational_manipulability(IKSolution_DevIter in_first, IKSolution_DevIter in_last, Vec8_DevIter out_first)
{
    TManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
    CUDA_ASSERT(cudaGetLastError());
}

__host__ inline
void compute_translational_manipulability(State_HostIter in_first, State_HostIter in_last, Float_HostIter out_first)
{
    TManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
}

__host__ inline
void compute_translational_manipulability(IKSolution_HostIter in_first, IKSolution_HostIter in_last, Vec8_HostIter out_first)
{
    TManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
}

struct RManipOpState
{
    __host__ __device__ 
    float operator()(const mt::State& state)
    {
        cumanip::Manipulability algo;
        algo.solve(state);
        return algo.rot_manip();
    }
    
    __host__ __device__
    mt::Vector<8> operator()(const IKSolution& sol)
    {
        mt::Vector<8> v(-1.f);
        int n = sol.num_solutions;
        for (int i = 0; i < n; ++i)
        {
            cumanip::Manipulability algo;
            algo.solve(sol.states.get_row(i));
            v.data[i] = algo.rot_manip();
        }
        return v;
    }
};


__host__ inline
void compute_rotational_manipulability(State_DevIter in_first, State_DevIter in_last, Float_DevIter out_first)
{
    RManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
    CUDA_ASSERT(cudaGetLastError());
}

__host__ inline
void compute_rotational_manipulability(IKSolution_DevIter in_first, IKSolution_DevIter in_last, Vec8_DevIter out_first)
{
    RManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
    CUDA_ASSERT(cudaGetLastError());
}

__host__ inline
void compute_rotational_manipulability(State_HostIter in_first, State_HostIter in_last, Float_HostIter out_first)
{
    RManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
}

__host__ inline
void compute_rotational_manipulability(IKSolution_HostIter in_first, IKSolution_HostIter in_last, Vec8_HostIter out_first)
{
    RManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
}



struct FManipOpState
{
    __host__ __device__ 
    float operator()(const mt::State& state)
    {
        cumanip::FullManipulability algo;
        algo.solve(state);
        return algo.manip();
    }
    
    __host__ __device__
    mt::Vector<8> operator()(const IKSolution& sol)
    {
        mt::Vector<8> v(-1.f);
        int n = sol.num_solutions;
        for (int i = 0; i < n; ++i)
        {
            cumanip::FullManipulability algo;
            algo.solve(sol.states.get_row(i));
            v.data[i] = algo.manip();
        }
        return v;
    }
};

__host__ inline
void compute_combine_manipulability(State_DevIter in_first, State_DevIter in_last, Float_DevIter out_first)
{
    FManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
    CUDA_ASSERT(cudaGetLastError());
}

__host__ inline
void compute_combined_manipulability(IKSolution_DevIter in_first, IKSolution_DevIter in_last, Vec8_DevIter out_first)
{
    FManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
    CUDA_ASSERT(cudaGetLastError());
}

__host__ inline
void compute_combined_manipulability(State_HostIter in_first, State_HostIter in_last, Float_HostIter out_first)
{
    FManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
}

__host__ inline
void compute_combined_manipulability(IKSolution_HostIter in_first, IKSolution_HostIter in_last, Vec8_HostIter out_first)
{
    FManipOpState op;
    thrust::transform(in_first, in_last, out_first, op);
}

__host__ inline 
float min_translational_manipulability(State_DevIter in_begin, State_DevIter in_end)
{
    size_t n = thrust::distance(in_begin, in_end);
    thrust::device_vector<float> xs(n);
    compute_translational_manipulability(in_begin, in_end, xs.begin());

    float res = thrust::reduce(xs.begin(), xs.end(), infty(), thrust::minimum<float>());
    return res;
}

__host__ inline 
float min_rotational_manipulability(State_DevIter in_begin, State_DevIter in_end)
{
    size_t n = thrust::distance(in_begin, in_end);
    thrust::device_vector<float> xs(n);
    compute_rotational_manipulability(in_begin, in_end, xs.begin());

    float res = thrust::reduce(xs.begin(), xs.end(), infty(), thrust::minimum<float>());
    return res;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <size_t NumRows>
struct GenTManipOpState
{
    __host__ __device__
    mt::Vector<NumRows> operator()(const mt::Matrix<NumRows, 6>& sol)
    {
        mt::Vector<NumRows> v(-1.f);
        for (int i = 0; i < NumRows; ++i)
        {
            cumanip::Manipulability algo;
            algo.solve(sol.get_row(i));
            v.at(i) = algo.trans_manip();
        }
        return v;
    }
};

template <size_t NumRows>
struct GenRManipOpState
{
    __host__ __device__
    mt::Vector<NumRows> operator()(const mt::Matrix<NumRows, 6>& sol)
    {
        mt::Vector<NumRows> v(-1.f);
        for (int i = 0; i < NumRows; ++i)
        {
            cumanip::Manipulability algo;
            algo.solve(sol.get_row(i));
            v.at(i) = algo.rot_manip();
        }
        return v;
    }
};

template <size_t NumRows>
__host__ inline 
void gen_compute_translational_manip(thrust::device_vector<mt::Matrix<NumRows, 6>>::iterator in_begin, 
                                     thrust::device_vector<mt::Matrix<NumRows, 6>>::iterator in_end,
                                     thrust::device_vector<mt::Vector<NumRows>>::iterator out_begin)
{
    GenTManipOpState<NumRows> op;
    thrust::transform(in_begin, in_end, out_begin, op);
}


} // namespace cumanip
#endif