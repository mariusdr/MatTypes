#ifndef LIBCUMANIP_TRAJECTORIES_FORWARD_KINEMATICS_H
#define LIBCUMANIP_TRAJECTORIES_FORWARD_KINEMATICS_H

#include <inrop/libcumanip/kinematics.hpp>
#include <inrop/libcumanip/typedefs.h>
#include <inrop/libcumanip/cuda_utils.h>

#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/execution_policy.h>



namespace cumanip 
{


__host__ inline 
void run_forward_kin(State_DevIter in_first, State_DevIter in_last, Mat4_DevIter out_first);




///////////////////////////////////////////////////////////////////////////////////////////////////////////////

struct RunFKOp : public thrust::unary_function<mt::State, mt::Matrix4f>
{
    __host__ __device__ 
    mt::Matrix4f operator()(const mt::State& state)
    {
        URKForwardKinematics fk;
        fk.solve(state);
        return fk.transform_base_to_ee(); 
    }
};

__host__ inline 
void run_forward_kin(State_DevIter in_first, State_DevIter in_last, Mat4_DevIter out_first)
{
    RunFKOp fkOp;
    thrust::transform(thrust::device, in_first, in_last, out_first, fkOp);
    CUDA_ASSERT(cudaGetLastError());
}



}
#endif