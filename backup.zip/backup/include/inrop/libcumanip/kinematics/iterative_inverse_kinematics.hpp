#ifndef LIBCUMANIP_KINEMATICS_ITERATIVE_INVERSE_KINEMATICS_HPP
#define LIBCUMANIP_KINEMATICS_ITERATIVE_INVERSE_KINEMATICS_HPP

#include <inrop/libcumanip/math_types.hpp>
#include <cstring>

namespace cumanip
{

class IterativeInverseKinematics 
{
public:

    __device__ __host__ 
    int solve(const mt::Matrix4f& T)
    {

    }

private:

};




}

#endif