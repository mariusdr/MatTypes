#ifndef DH_PARAMS_HPP
#define DH_PARAMS_HPP

#ifdef UR10_PARAMS
#define d1  0.1273f
#define a2 -0.612f
#define a3 -0.5723f
#define d4  0.163941f
#define d5  0.1157f
#define d6  0.0922f
#define ur_len
#endif

#ifdef UR5_PARAMS
#define d1  0.089159f
#define a2 -0.42500f
#define a3 -0.39225f
#define d4  0.10915f
#define d5  0.09465f
#define d6  0.0823f
#endif

#ifdef UR3_PARAMS
#define d1  0.1519f
#define a2 -0.24365f
#define a3 -0.21325f
#define d4  0.11235f
#define d5  0.08535f
#define d6  0.0819f
#endif

#ifdef UR10E_PARAMS
#define d1  0.1807f
#define a2 -0.6127f
#define a3 -0.57155f
#define d4  0.17415f
#define d5  0.11985f
#define d6  0.11655f
#define ur_len
#endif

#ifdef UR5E_PARAMS
#define d1  0.1625f
#define a2 -0.42500f
#define a3 -0.39220f
#define d4  0.1333f
#define d5  0.09970f
#define d6  0.0996f
#endif

#ifdef UR3E_PARAMS
#define d1  0.15185f
#define a2 -0.24355f
#define a3 -0.2132f
#define d4  0.13105f
#define d5  0.08535f
#define d6  0.0921f
#endif

#ifdef UR16E_PARAMS
#define d1  0.1807f
#define a2 -0.4784f
#define a3 -0.36f
#define d4  0.17415f
#define d5  0.11985f
#define d6  0.11655f
#define ur_len
#endif


#endif