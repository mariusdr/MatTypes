#ifndef LIBCUMANIP_CUDA_PATH_PLANNING_H
#define LIBCUMANIP_CUDA_PATH_PLANNING_H

#include <inrop/libcumanip/forward_kinematics_op.h>
#include <inrop/libcumanip/manipulability_op.h>
#include <inrop/libcumanip/inverse_kinematics_op.h>
#include <inrop/libcumanip/common_op.h>
#include <inrop/libcumanip/cuda_utils.h>

#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/transform_scan.h>

namespace cumanip
{

struct ComputeDistanceMatrixOp
{
    __device__ __host__ 
    ComputeDistanceMatrixOp(mt::Matrix<6, 6> joint_weights): joint_weights(joint_weights)
    {}
    
    __device__ __host__ 
    ComputeDistanceMatrixOp(): joint_weights(mt::identity<6, 6>())
    {}

    __device__ __host__ 
    mt::Matrix<8, 8> operator()(const IKSolution& fst, const IKSolution& snd)
    {
        mt::Matrix<8, 8> dm(infty());
        for (size_t i = 0; i < 8; ++i)
        {
            for (size_t j = 0; j < 8; ++j)
            {
                const mt::State si = fst.states.get_row(i);
                const mt::State sj = snd.states.get_row(j);
                float dist = mt::distance(joint_weights, si, sj);
                dm.data[i * 8 + j] = dist; 
            }
        }
        return dm;
    }
    
    __device__ __host__
    mt::Matrix<8, 8> operator()(const thrust::tuple<IKSolution, IKSolution>& p)
    {
        return (*this)(thrust::get<0>(p), thrust::get<1>(p));
    }

    mt::Matrix<6, 6> joint_weights;
};

struct ComputeTransitionMatrixOp
{
    __device__ __host__ 
    ComputeTransitionMatrixOp(float md): max_dist(md)
    {}

    __device__ __host__
    mt::Matrix8f operator()(const mt::Matrix8f& distance_matrix)
    {
        mt::Matrix8f out(0.f);
        for (size_t i = 0; i < 8; ++i)
        {
            for (size_t j = 0; j < 8; ++j)
            {
                float dist = distance_matrix.data[i * 8 + j];
                out.data[i * 8 + j] = (dist <= max_dist) ? 1.f : 0.f;
            }
        }
        return out;
    }
    
    float max_dist;
};


__host__ inline 
void compute_transition_matricies(float max_dist, mt::Matrix<6, 6> dweights, 
                                  IKSolution_DevIter in_begin, IKSolution_DevIter in_end, 
                                  Mat8_DevIter out_begin)
{
    size_t n = thrust::distance(in_begin, in_end);
    thrust::device_vector<mt::Matrix8f> dms_dev(n - 1);

    // compute distances between states of ik solutions

    IKSolution_DevIter fst_begin = in_begin;
    IKSolution_DevIter fst_end = in_end - 1;
    
    IKSolution_DevIter snd_begin = in_begin + 1;
    IKSolution_DevIter snd_end = in_end - 1;

    auto zip_begin = thrust::make_zip_iterator(thrust::make_tuple(fst_begin, snd_begin));
    auto zip_end = thrust::make_zip_iterator(thrust::make_tuple(fst_end, snd_end));

    ComputeDistanceMatrixOp dm_op;
    thrust::transform(zip_begin, zip_end, dms_dev.begin(), dm_op);
    CUDA_ASSERT(cudaGetLastError());

    // compute transition matricies

    ComputeTransitionMatrixOp tm_op(max_dist);
    thrust::transform(dms_dev.begin(), dms_dev.end(), out_begin, tm_op);
    CUDA_ASSERT(cudaGetLastError());
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <size_t NumRows>
struct GenComputeDistanceMatrixOp
{
    using InMatrix = mt::Matrix<NumRows, 6>;
    using OutMatrix = mt::Matrix<NumRows, NumRows>;

    __device__ __host__ 
    GenComputeDistanceMatrixOp(mt::Matrix<6, 6> joint_weights): joint_weights(joint_weights)
    {}
    
    __device__ __host__ 
    GenComputeDistanceMatrixOp(): joint_weights(mt::identity<6, 6>())
    {}

    __device__ __host__ 
    OutMatrix operator()(const InMatrix& fst, const InMatrix& snd)
    {
        OutMatrix dm(infty());

        for (size_t i = 0; i < NumRows; ++i)
        {
            for (size_t j = 0; j < NumRows; ++j)
            {
                const mt::State si = fst.get_row(i);
                const mt::State sj = snd.get_row(j);
                float dist = mt::distance(joint_weights, si, sj);
                dm.at(i, j) = dist; 
            }
        }
        return dm;
    }
    
    __device__ __host__
    OutMatrix operator()(const thrust::tuple<InMatrix, InMatrix>& p)
    {
        return (*this)(thrust::get<0>(p), thrust::get<1>(p));
    }

    mt::Matrix<6, 6> joint_weights;
};

template <size_t NumRows>
struct GenComputeTransitionMatrixOp
{
    using MatrixN = mt::Matrix<NumRows, NumRows>;

    __device__ __host__ 
    GenComputeTransitionMatrixOp(float md): max_dist(md)
    {}

    __device__ __host__
    MatrixN operator()(const MatrixN& distance_matrix)
    {
        MatrixN out(0.f);
        for (size_t i = 0; i < NumRows; ++i)
        {
            for (size_t j = 0; j < NumRows; ++j)
            {
                const float dist = distance_matrix.at(i, j);
                out.at(i, j) = (dist <= max_dist) ? 1.f : 0.f;
            }
        }
        return out;
    }
    
    float max_dist;
};


template <size_t NumRows>
__host__ inline 
void gen_compute_transition_matricies(float max_dist, mt::Matrix<6, 6> dweights,
                                      thrust::device_vector<mt::Matrix<NumRows, 6>>::iterator in_begin, 
                                      thrust::device_vector<mt::Matrix<NumRows, 6>>::iterator in_end,
                                      thrust::device_vector<mt::Matrix<NumRows, NumRows>>::iterator out_begin)
{
    size_t n = thrust::distance(in_begin, in_end);
    thrust::device_vector<mt::Matrix<NumRows, NumRows>> dms_dev(n - 1);

    // compute distances between states of ik solutions

    // IKSolution_DevIter fst_begin = in_begin;
    // IKSolution_DevIter fst_end = in_end - 1;
    
    // IKSolution_DevIter snd_begin = in_begin + 1;
    // IKSolution_DevIter snd_end = in_end - 1;

    auto zip_begin = thrust::make_zip_iterator(thrust::make_tuple(in_begin, in_begin + 1));
    auto zip_end = thrust::make_zip_iterator(thrust::make_tuple(in_end - 1, in_end - 1));

    GenComputeDistanceMatrixOp<NumRows> dm_op;
    thrust::transform(zip_begin, zip_end, dms_dev.begin(), dm_op);
    CUDA_ASSERT(cudaGetLastError());


     // compute transition matricies

    GenComputeTransitionMatrixOp<NumRows> tm_op(max_dist);
    thrust::transform(dms_dev.begin(), dms_dev.end(), out_begin, tm_op);
    CUDA_ASSERT(cudaGetLastError());
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <size_t NumRows>
struct GenComputeManipMatrixOp 
{
    using TMatrix = mt::Matrix<NumRows, NumRows>;
    using MVector = mt::Vector<NumRows>;

    using VecMatVec = thrust::tuple<MVector, TMatrix, MVector>;

    __device__ __host__ 
    TMatrix operator()(const VecMatVec& inp)
    {
        MVector manip_from = thrust::get<0>(inp);
        TMatrix tmat = thrust::get<1>(inp);
        MVector manip_to = thrust::get<2>(inp);

        TMatrix mmat(0.f);
        for (size_t i = 0; i < 8; ++i)
        {
            for (size_t j = 0; j < 8; ++j)
            {
                float mi = manip_from.at(i);
                float mj = manip_to.at(j);
                float m = thrust::min(mi, mj);

                mmat.at(i, j) = (tmat.at(i, j) > 0.f) ? m : 0.f;
            }
        }
        return mmat;
    }
};


template <size_t NumRows>
struct Foo
{
    using TMatrix = mt::Matrix<NumRows, NumRows>;

    __device__ __host__
    TMatrix operator()(TMatrix a, TMatrix b)
    {
        return a + b;
    } 
};


template <size_t NumRows>
__host__ inline 
void gen_compute_manip_matricies(thrust::device_vector<mt::Matrix<NumRows, NumRows>>::iterator tm_begin, 
                                 thrust::device_vector<mt::Matrix<NumRows, NumRows>>::iterator tm_end, 
                                 thrust::device_vector<mt::Vector<NumRows>>::iterator manip_begin,
                                 thrust::device_vector<mt::Vector<NumRows>>::iterator manip_end, 
                                 thrust::device_vector<mt::Matrix<NumRows, NumRows>>::iterator out_begin)
{
    auto vmv_begin = thrust::make_zip_iterator(
        thrust::make_tuple(manip_begin, tm_begin, manip_begin + 1)
    );

    auto vmv_end = thrust::make_zip_iterator(
        thrust::make_tuple(manip_end - 1, tm_end, manip_end)
    );

    GenComputeManipMatrixOp<NumRows> tf_op;
    Foo<NumRows> red_op;

    // thrust::transform(vmv_begin, vmv_end, out_begin, op);
    thrust::transform_inclusive_scan(vmv_begin, vmv_end, out_begin, tf_op, red_op);
    CUDA_ASSERT(cudaGetLastError());
}

template <size_t NumRows>
struct GenCombineManipMatrixOp
{
    using TMatrix = mt::Matrix<NumRows, NumRows>;

    __device__ __host__
    TMatrix operator()(const TMatrix& fst, const TMatrix& snd)
    {
        TMatrix out(0.f);

        // for (unsigned int i = 0; i < NumRows; ++i)
        // {
        //     for (unsigned int j = 0; j < NumRows; ++j)
        //     {
        //         float max_m = 0.f;
        //         // for (size_t k = 0; k < NumRows; ++k)
        //         // {
        //         //     // const float& m_ik = fst.at(i, k);
        //         //     // const float& m_kj = snd.at(k, j);
        //         //     // const float& m = thrust::min(m_ik, m_kj);
        //         //     const float m = thrust::min(fst.at(i, k), snd.at(k, j));
        //         //     //max_m = thrust::max(max_m, m);
        //         //     max_m = m;
        //         // }
        //         out.at(i, j) = max_m;
        //     }
        // }
        return out;
    }
};



template <size_t NumRows>
__host__ inline 
void gen_combine_manip_matricies(thrust::device_vector<mt::Matrix<NumRows, NumRows>>::iterator in_begin, 
                                 thrust::device_vector<mt::Matrix<NumRows, NumRows>>::iterator in_end, 
                                 thrust::device_vector<mt::Matrix<NumRows, NumRows>>::iterator out_begin)
{
    GenCombineManipMatrixOp<NumRows> op;
    thrust::inclusive_scan(in_begin, in_end, out_begin, Foo<NumRows>());
    CUDA_ASSERT(cudaGetLastError());
}



} // namespace cumanip
#endif