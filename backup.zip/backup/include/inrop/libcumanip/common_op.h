#ifndef LIBCUMANIP_COMMON_OPS_H
#define LIBCUMANIP_COMMON_OPS_H

#include <inrop/libcumanip/kinematics.hpp>
#include <inrop/libcumanip/typedefs.h>

#include <cstring>

#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/execution_policy.h>
#include <thrust/for_each.h>

#include <thrust/random.h>
#include <thrust/iterator/counting_iterator.h>

namespace cumanip
{


__host__ inline 
void convert_point_to_affine(Point_DevIter in_first, Point_DevIter in_last, Mat4_DevIter out_first);

__host__ inline 
void convert_point_to_affine(Point_HostIter in_first, Point_HostIter in_last, Mat4_HostIter out_first);

__host__ inline 
void convert_affine_to_point(Mat4_DevIter in_first, Mat4_DevIter in_last, Point_DevIter out_first);

__host__ inline 
void convert_affine_to_point(Mat4_HostIter in_first, Mat4_HostIter in_last, Point_HostIter out_first);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

struct PointToAffine
{
    __device__ __host__ 
    mt::Matrix4f operator()(const mt::Point& pt)
    {
        return mt::point_to_affine(pt);
    }
};

struct AffineToPoint
{
    __device__ __host__
    mt::Point operator()(const mt::Matrix4f& mat)
    {
        return mt::affine_to_point(mat);
    }
};


__host__ inline
void convert_point_to_affine(Point_DevIter in_first, Point_DevIter in_last, Mat4_DevIter out_first)
{
    PointToAffine op;
    thrust::transform(thrust::device, in_first, in_last, out_first, op);
}

__host__ inline
void convert_point_to_affine(Point_HostIter in_first, Point_HostIter in_last, Mat4_HostIter out_first)
{
    PointToAffine op;
    thrust::transform(thrust::host, in_first, in_last, out_first, op);
}

__host__ inline
void convert_affine_to_point(Mat4_DevIter in_first, Mat4_DevIter in_last, Point_DevIter out_first)
{
    AffineToPoint op;
    thrust::transform(thrust::device, in_first, in_last, out_first, op);
}

__host__ inline
void convert_affine_to_point(Mat4_HostIter in_first, Mat4_HostIter in_last, Point_HostIter out_first)
{
    AffineToPoint op;
    thrust::transform(thrust::host, in_first, in_last, out_first, op);
}


struct RightTransform
{
    RightTransform(mt::Matrix4f t): transform(t) 
    {}

    __host__ __device__
    mt::Matrix4f operator()(const mt::Matrix4f& inp)
    {
        return inp * transform;
    }
    
    mt::Matrix4f transform;
};

__host__ inline 
void apply_right(Mat4_DevIter in_begin, Mat4_DevIter in_end, Mat4_DevIter out_begin, const mt::Matrix4f& transformation)
{
    RightTransform op(transformation);
    thrust::transform(thrust::device, in_begin, in_end, out_begin, op);
}



struct LeftTransform
{
    LeftTransform(mt::Matrix4f t): transform(t) 
    {}

    __host__ __device__
    mt::Matrix4f operator()(const mt::Matrix4f& inp)
    {
        return transform * inp;
    }
    
    mt::Matrix4f transform;
};

__host__ inline 
void apply_left(Mat4_DevIter in_begin, Mat4_DevIter in_end, Mat4_DevIter out_begin, const mt::Matrix4f& transformation)
{
    LeftTransform op(transformation);
    thrust::transform(thrust::device, in_begin, in_end, out_begin, op);
}


struct GetXYZfromPoint
{
    __host__ __device__ 
    mt::Vector3f operator()(const mt::Point& point)
    {
        return mt::get_coords(point);
    }
};

__host__ inline 
void get_xyz(Point_DevIter in_begin, Point_DevIter in_end, Vec3f_DevIter out_begin)
{
    GetXYZfromPoint op;
    thrust::transform(thrust::device, in_begin, in_end, out_begin, op);
}


template <size_t NumSamples>
struct RandomRPY
{
    __host__ __device__ 
    mt::Matrix<NumSamples, 3> operator()(const unsigned int n) const
    {
        thrust::minstd_rand rng;
        thrust::uniform_real_distribution<float> dist(0.f, 2 * M_PI);
        rng.discard(n * 3 * NumSamples);

        mt::Matrix<NumSamples, 3> samples;
        for (size_t i = 0; i < NumSamples; ++i)
        {
            float r = dist(rng);
            float p = dist(rng);
            float y = dist(rng);

            mt::Vector3f rpy = mt::vec3f(r, p, y);
            samples.set_row(i, rpy);
        }
        return samples;
    }
};

template <size_t NumSamples>
__host__ inline 
void gen_rand_rpy(thrust::device_vector<mt::Matrix<NumSamples, 3>>::iterator in_begin, 
                  thrust::device_vector<mt::Matrix<NumSamples, 3>>::iterator in_end)
{
    size_t n = thrust::distance(in_begin, in_end);

    if (NumSamples * n >= thrust::minstd_rand::max)
    {
        std::cout << "Warning: NumSamples * n = " << NumSamples *  n << " is greater than the period " 
        << thrust::minstd_rand::max << " of the random engine!\n";
    }

    thrust::counting_iterator<size_t> idx_begin(0);
    thrust::counting_iterator<size_t> idx_end(n);
    thrust::transform(idx_begin, idx_end, in_begin, RandomRPY<NumSamples>());
}



} // namespace
#endif