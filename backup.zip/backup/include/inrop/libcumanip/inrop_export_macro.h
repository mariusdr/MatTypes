#ifndef LIBCUMANIP_INROP_EXPORT_MACROS_H
#define LIBCUMANIP_INROP_EXPORT_MACROS_H


#include <inrop/InropExportMacros.h>

#if defined(LIBCUMANIP_BUILD_STATIC)
    #define LIBCUMANIP_DECL
#else
    #if defined(libcumanip_EXPORTS)
        #define LIBCUMANIP_DECL INROP_DECL_EXPORT
    #else
        #define LIBCUMANIP_DECL INROP_DECL_IMPORT
    #endif
#endif



#endif