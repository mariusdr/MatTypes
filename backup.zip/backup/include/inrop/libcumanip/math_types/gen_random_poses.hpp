#ifndef LIBCUMANIP_TYPES_GEN_RANDOM_POSES_HPP
#define LIBCUMANIP_TYPES_GEN_RANDOM_POSES_HPP

#include <inrop/libcumanip/math_types/matrix.hpp>
#include <inrop/libcumanip/math_types/utils.hpp>
#include <inrop/libcumanip/math_types/vector.hpp>
#include <inrop/libcumanip/math_types/geometry.hpp>

#ifndef _USE_MATH_DEFINES
#define _USE_MATH_DEFINES
#endif
#include <math.h>

#include <thrust/random/linear_congruential_engine.h>
#include <thrust/random/uniform_real_distribution.h>


namespace cumanip 
{
namespace mt 
{

__host__ __device__ inline
Matrix4f rand_pose_from_xyz(const Vector3f& xyz)
{
    thrust::minstd_rand rng;
    thrust::uniform_real_distribution<float> dist(0, 2 * M_PI);
    float r = dist(rng);
    float p = dist(rng);
    float y = dist(rng);
    Matrix3f rpy = fromRPY(r, p, y);

    return affine(rpy, xyz);
}




} // namespace mt
} // namespace cumanip 
#endif