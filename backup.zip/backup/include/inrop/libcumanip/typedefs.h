#ifndef LIBCUMANIP_TYPEDEFS_H
#define LIBCUMANIP_TYPEDEFS_H

#include <inrop/libcumanip/math_types.hpp>
#include <inrop/libcumanip/kinematics.hpp>

#include <thrust/host_vector.h>
#include <thrust/device_vector.h>

#include <vector>

namespace cumanip
{

using StateTrajectorySTL = std::vector<mt::State>;
using StateTrajectoryDev = thrust::device_vector<mt::State>;
using StateTrajectoryHost = thrust::host_vector<mt::State>;

using Point_STLIter = std::vector<mt::Point>::iterator;
using Point_DevIter = thrust::device_vector<mt::Point>::iterator;
using Point_HostIter = thrust::host_vector<mt::Point>::iterator;

using Vec3f_STLIter = std::vector<mt::Vector3f>::iterator;
using Vec3f_DevIter = thrust::device_vector<mt::Vector3f>::iterator;
using Vec3f_HostIter = thrust::host_vector<mt::Vector3f>::iterator;

using Mat4_STLIter = std::vector<mt::Matrix4f>::iterator;
using Mat4_DevIter = thrust::device_vector<mt::Matrix4f>::iterator;
using Mat4_HostIter = thrust::host_vector<mt::Matrix4f>::iterator;

using Mat8_STLIter = std::vector<mt::Matrix8f>::iterator;
using Mat8_DevIter = thrust::device_vector<mt::Matrix8f>::iterator;
using Mat8_HostIter = thrust::host_vector<mt::Matrix8f>::iterator;

using Vec8_STLIter = std::vector<mt::Vector<8>>::iterator;
using Vec8_DevIter = thrust::device_vector<mt::Vector<8>>::iterator;
using Vec8_HostIter = thrust::host_vector<mt::Vector<8>>::iterator;

using State_STLIter = std::vector<mt::State>::iterator;
using State_DevIter = thrust::device_vector<mt::State>::iterator;
using State_HostIter = thrust::host_vector<mt::State>::iterator;

struct IKSolution;
using IKSolution_STLIter = std::vector<IKSolution>::iterator;
using IKSolution_DevIter = thrust::device_vector<IKSolution>::iterator;
using IKSolution_HostIter = thrust::host_vector<IKSolution>::iterator;

using Float_STLIter = std::vector<float>::iterator;
using Float_DevIter = thrust::device_vector<float>::iterator;
using Float_HostIter = thrust::host_vector<float>::iterator;


} // namespace
#endif