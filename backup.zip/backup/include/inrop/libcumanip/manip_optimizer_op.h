#ifndef LIBCUMANIP_MANIPULABILITY_OPTIMIZER_H
#define LIBCUMANIP_MANIPULABILITY_OPTIMIZER_H

#include <inrop/libcumanip/kinematics.hpp>
#include <inrop/libcumanip/typedefs.h>

#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/execution_policy.h>
#include <thrust/tuple.h>


namespace cumanip
{

struct OptimizerResult 
{
    thrust::host_vector<thrust::host_vector<mt::State>> trajectories;
    thrust::host_vector<float> manip_values;
};

OptimizerResult run_optimizer(const thrust::host_vector<mt::State> &inp_states,
                              mt::Matrix<6, 6> dist_weigths,
                              float max_dist, mt::Matrix4f offset_transformation);

void compute_manip_single_traj(const thrust::host_vector<mt::State>& inp_states, float& tmanip, float& rmanip);

} // namespace
#endif