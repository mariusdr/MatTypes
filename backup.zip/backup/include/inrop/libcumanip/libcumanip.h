#ifndef LIBCUMANIP_LIBCUMANIP_H
#define LIBCUMANIP_LIBCUMAIP_H

#include <inrop/libcumanip/inrop_export_macro.h>

#include <inrop/planning/MotionTrajectory.h>


namespace cumanip
{



class LIBCUMANIP_DECL CudaManipulability 
{
public:
    
    CudaManipulability(inrop::planning::MotionTrajectoryPtr motion, 
                       float dw0, float dw1, float dw2, float dw3, float dw4, float dw5, 
                       float max_dist);

    ~CudaManipulability();
    
    void optimize();
    
    void compute_manipulability(float& tmanip, float& rmanip);
    
    size_t num_solutions() const;
    
    inrop::planning::MotionTrajectoryPtr get_solution(size_t i) const;
    
    float get_manip(size_t i) const;

    void set_offset_transform(const std::vector<float>& vals);

private:
    
    // PIMPL to hide cuda device functions from c++ code that includes this header
    class Impl;
    Impl* impl;
};












} // namespace
#endif